package com.ejemplo.coilmatching;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoilMatchingApplication {
    public static void main(String[] args) {
        SpringApplication.run(CoilMatchingApplication.class, args);
    }
}